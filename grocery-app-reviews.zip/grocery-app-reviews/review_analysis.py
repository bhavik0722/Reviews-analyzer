#!/usr/bin/env python3
"""Collect recent public Google Play reviews and produce an issue analysis.

Review text is processed in memory and is not written to the output files.
The exported row-level file contains only ratings, dates, app versions, and
derived labels, so it is useful for analysis without republishing review text.
"""

from __future__ import annotations

import argparse
import csv
import html
import json
import re
import statistics
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path


APPS = [
    {"name": "Blinkit", "package": "com.grofers.customerapp"},
    {"name": "Zepto", "package": "com.zeptoconsumerapp"},
    {"name": "BigBasket", "package": "com.bigbasket.mobileapp"},
]

ISSUE_THEMES = {
    "Delivery reliability": [
        "late", "delay", "delayed", "not delivered", "never delivered",
        "not received", "did not receive", "didn't receive", "no delivery",
        "fake delivery", "delivery time", "delivery was cancelled",
        "order was cancelled", "order got cancelled", "cancelled my order",
        "canceled my order", "cancelled order", "canceled order",
    ],
    "Missing / wrong / poor-quality items": [
        "missing item", "missing items", "missing product", "wrong item",
        "wrong product", "empty box", "damaged", "rotten", "expired",
        "stale", "spoiled", "poor quality", "bad quality", "low quality",
        "not fresh", "unsealed", "out of stock", "item was not available",
        "less quantity", "short quantity", "quantity was less",
    ],
    "Refunds & payment problems": [
        "refund", "refunded", "refunds", "charged twice", "double payment",
        "extra charge", "charged full", "payment failed", "payment issue",
        "money deducted", "money lost", "wallet", "billing issue",
    ],
    "Customer support / resolution": [
        "customer support", "customer care", "support team", "no support",
        "no customer support", "no chat", "chat support", "no response",
        "unhelpful", "not helpful", "not responding", "poor response",
        "unresponsive", "can't reach", "cannot reach", "unable to reach",
        "complaint", "resolve the issue", "not resolved", "no resolution",
    ],
    "Prices, fees & offers": [
        "expensive", "overpriced", "high price", "price increased",
        "price changed", "price difference", "hidden charge", "handling fee",
        "delivery fee", "platform fee", "coupon", "discount", "offer",
        "charged full amount", "more money", "extra money", "not worth",
    ],
    "App / cart / account friction": [
        "app is not working", "app not working", "app crash", "crash",
        "keeps crashing", "not loading", "doesn't load", "does not load",
        "login issue", "can't login", "cannot login", "otp", "cart vanished",
        "cart disappeared", "removed from my cart", "items vanished",
        "error message", "technical issue", "bug", "glitch", "max daily limit",
    ],
}

POSITIVE_THEMES = {
    "Fast delivery / convenience": [
        "fast", "quick", "on time", "within minutes", "convenient",
        "easy to use", "easy app", "quick service",
    ],
    "Product quality / range": [
        "fresh", "good quality", "great quality", "good product", "wide range",
        "variety", "quality products",
    ],
    "Value / offers": [
        "value for money", "good price", "low price", "affordable", "discount",
        "good offer", "offers",
    ],
    "Good service": ["good service", "great service", "helpful", "responsive"],
}

RECOMMENDATIONS = {
    "Delivery reliability": "Set realistic ETAs, flag likely misses early, and offer clear order status and recovery options.",
    "Missing / wrong / poor-quality items": "Improve stock accuracy and pick/pack checks; let customers approve substitutions and report quality problems with less friction.",
    "Refunds & payment problems": "Reconcile payment state before asking customers to pay again, and show refund amount, destination, and expected settlement date.",
    "Customer support / resolution": "Provide a direct path to a human for order failures and keep one visible case status until the issue is resolved.",
    "Prices, fees & offers": "Keep the checkout total stable, disclose fees before payment, and preserve discounts shown when the order is placed.",
    "App / cart / account friction": "Prioritize cart persistence, clear limit explanations, and recoverable login and checkout errors.",
}


def norm_text(value: object) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip().casefold()


def rating_sentiment(score: int) -> str:
    if score <= 2:
        return "Negative"
    if score == 3:
        return "Neutral"
    return "Positive"


def matches(text: str, phrases: list[str]) -> bool:
    for phrase in phrases:
        pattern = r"(?<!\w)" + re.escape(phrase).replace(r"\ ", r"\s+") + r"(?!\w)"
        if re.search(pattern, text):
            return True
    return False


def pct(value: int, total: int) -> float:
    return (100.0 * value / total) if total else 0.0


def write_csv(path: Path, headers: list[str], rows: list[dict]) -> None:
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=headers)
        writer.writeheader()
        writer.writerows(rows)


def rating_chart_svg(app_rows: list[dict]) -> str:
    width, height = 940, 390
    left, right, top, bottom = 235, 26, 40, 54
    chart_w = width - left - right
    bar_h, gap = 44, 38
    colors = {"Positive": "#2f8f6b", "Neutral": "#e3a63a", "Negative": "#c95555"}
    pieces = [
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}" role="img" aria-label="Review sentiment by app">',
        '<rect width="100%" height="100%" fill="#fff"/>',
        '<text x="20" y="27" font-family="Arial" font-size="17" font-weight="700" fill="#182332">Rating-based sentiment in the collected review sample</text>',
    ]
    for tick in (0, 25, 50, 75, 100):
        x = left + chart_w * tick / 100
        pieces.append(f'<line x1="{x:.1f}" y1="{top}" x2="{x:.1f}" y2="{height-bottom+2}" stroke="#e4e9ef"/>')
        pieces.append(f'<text x="{x:.1f}" y="{height-20}" text-anchor="middle" font-family="Arial" font-size="12" fill="#5e6b78">{tick}%</text>')
    for i, row in enumerate(app_rows):
        y = top + 18 + i * (bar_h + gap)
        pieces.append(f'<text x="{left-16}" y="{y+bar_h/2+5:.1f}" text-anchor="end" font-family="Arial" font-size="14" font-weight="600" fill="#263548">{html.escape(row["app_name"])}</text>')
        x = left
        for sentiment in ("Positive", "Neutral", "Negative"):
            value = row[f"{sentiment.lower()}_pct"]
            seg_w = chart_w * value / 100
            if seg_w > 0:
                pieces.append(f'<rect x="{x:.1f}" y="{y}" width="{seg_w:.1f}" height="{bar_h}" rx="3" fill="{colors[sentiment]}"/>')
                if value >= 7:
                    pieces.append(f'<text x="{x+seg_w/2:.1f}" y="{y+bar_h/2+5:.1f}" text-anchor="middle" font-family="Arial" font-size="12" font-weight="700" fill="#fff">{value:.0f}%</text>')
            x += seg_w
        pieces.append(f'<text x="{left+chart_w+8}" y="{y+bar_h/2+5:.1f}" font-family="Arial" font-size="12" fill="#5e6b78">n={row["reviews_collected"]}</text>')
    legend_y = height - 1
    lx = left
    for sentiment, label in (("Positive", "4–5 stars"), ("Neutral", "3 stars"), ("Negative", "1–2 stars")):
        pieces.append(f'<rect x="{lx}" y="{legend_y-12}" width="13" height="13" rx="2" fill="{colors[sentiment]}"/>')
        pieces.append(f'<text x="{lx+19}" y="{legend_y}" font-family="Arial" font-size="12" fill="#384657">{label}</text>')
        lx += 135
    pieces.append('</svg>')
    return "".join(pieces)


def issue_chart_svg(issue_rows: list[dict], apps: list[str]) -> str:
    themes = list(dict.fromkeys(row["theme"] for row in issue_rows))
    values = {(row["app_name"], row["theme"]): row["negative_reviews"] for row in issue_rows}
    max_val = max(values.values(), default=1) or 1
    width, height = 940, max(300, 86 + len(themes) * 52)
    left, right, top = 255, 42, 43
    chart_w = width - left - right
    colors = {"Blinkit": "#476f9c", "Zepto": "#735ab2", "BigBasket": "#d17a36"}
    pieces = [
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}" role="img" aria-label="Issue themes in low-rated reviews">',
        '<rect width="100%" height="100%" fill="#fff"/>',
        '<text x="20" y="27" font-family="Arial" font-size="17" font-weight="700" fill="#182332">Issue themes in 1–2 star reviews</text>',
    ]
    for i, theme in enumerate(themes):
        y = top + i * 52
        pieces.append(f'<text x="{left-12}" y="{y+22}" text-anchor="end" font-family="Arial" font-size="12" fill="#263548">{html.escape(theme)}</text>')
        for j, app in enumerate(apps):
            value = values.get((app, theme), 0)
            bar_y = y + j * 11
            bar_w = chart_w * value / max_val if max_val else 0
            pieces.append(f'<rect x="{left}" y="{bar_y}" width="{bar_w:.1f}" height="8" rx="3" fill="{colors.get(app, "#718096")}"/>')
            pieces.append(f'<text x="{left+bar_w+5:.1f}" y="{bar_y+8}" font-family="Arial" font-size="10" fill="#5e6b78">{value}</text>')
    lx, ly = left, height - 14
    for app in apps:
        pieces.append(f'<rect x="{lx}" y="{ly-10}" width="11" height="11" rx="2" fill="{colors.get(app, "#718096")}"/>')
        pieces.append(f'<text x="{lx+16}" y="{ly}" font-family="Arial" font-size="11" fill="#384657">{html.escape(app)}</text>')
        lx += 120
    pieces.append('</svg>')
    return "".join(pieces)


def build_report(output_dir: Path, summary: list[dict], issue_rows: list[dict], positive_rows: list[dict], meta: dict) -> None:
    app_names = [row["app_name"] for row in summary]
    ratings_svg = rating_chart_svg(summary)
    issues_svg = issue_chart_svg(issue_rows, app_names)
    top_lines = []
    for row in summary:
        app = row["app_name"]
        problems = [x for x in issue_rows if x["app_name"] == app and x["negative_reviews"] > 0]
        problems.sort(key=lambda x: (-x["negative_reviews"], x["theme"]))
        praises = [x for x in positive_rows if x["app_name"] == app and x["positive_reviews"] > 0]
        praises.sort(key=lambda x: (-x["positive_reviews"], x["theme"]))
        problem_text = ", ".join(f'{x["theme"]} ({x["negative_reviews"]})' for x in problems[:2]) or "No recurring keyword theme surfaced in the sample"
        praise_text = ", ".join(f'{x["theme"]} ({x["positive_reviews"]})' for x in praises[:2]) or "No recurring praise keyword surfaced in the sample"
        top_lines.append(f'<tr><th>{html.escape(app)}</th><td>{html.escape(problem_text)}</td><td>{html.escape(praise_text)}</td><td>{row["average_rating"]:.2f} / 5</td></tr>')

    sample_table = []
    for row in summary:
        sample_table.append(
            f'<tr><td>{html.escape(row["app_name"])}</td><td>{row["reviews_collected"]}</td>'
            f'<td>{html.escape(row["date_from"] or "—")}</td><td>{html.escape(row["date_to"] or "—")}</td>'
            f'<td>{row["negative_pct"]:.1f}%</td></tr>'
        )
    generated = html.escape(meta["collected_at_utc"])
    report = f'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Quick Commerce App Review Analysis</title>
<style>
  :root {{ --ink:#1d2938; --muted:#586779; --line:#dce3ea; --blue:#244566; --bg:#f4f7fa; }}
  * {{ box-sizing:border-box; }} body {{ margin:0; background:var(--bg); color:var(--ink); font:15px/1.55 Arial,Helvetica,sans-serif; }}
  main {{ max-width:1100px; margin:28px auto; padding:0 18px 42px; }} header {{ background:linear-gradient(120deg,#173550,#2a6286); color:#fff; padding:28px 32px; border-radius:16px; }}
  h1 {{ margin:0 0 6px; font-size:30px; }} h2 {{ margin:0 0 14px; font-size:20px; }} header p {{ margin:0; color:#e2edf4; }}
  section {{ background:#fff; border:1px solid var(--line); border-radius:14px; padding:22px; margin-top:18px; box-shadow:0 2px 8px #1735500b; }}
  .cards {{ display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:12px; margin-top:18px; }} .card {{ background:#ffffff18; padding:14px; border-radius:10px; }} .card strong {{ display:block; font-size:22px; }}
  .chart {{ overflow-x:auto; }} svg {{ display:block; width:100%; min-width:680px; height:auto; }} table {{ width:100%; border-collapse:collapse; margin:10px 0; }} th,td {{ text-align:left; vertical-align:top; padding:10px 9px; border-bottom:1px solid var(--line); }} th {{ color:var(--blue); }}
  .note {{ color:var(--muted); font-size:13px; }} .callout {{ background:#f1f6fb; border-left:4px solid #4775a0; padding:13px 16px; border-radius:4px; }}
  .rec-grid {{ display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:12px; }} .rec {{ border:1px solid var(--line); border-radius:10px; padding:12px 14px; }} .rec strong {{ display:block; margin-bottom:4px; }}
  @media(max-width:700px) {{ .cards,.rec-grid {{grid-template-columns:1fr}} header {{padding:22px}} h1 {{font-size:25px}} section {{padding:16px}} }}
</style></head><body><main>
<header><h1>Quick Commerce App Review Analysis</h1><p>Blinkit, Zepto, and BigBasket • Google Play India • newest English review sample</p>
<div class="cards">{''.join(f'<div class="card"><strong>{html.escape(r["app_name"])}</strong>{r["reviews_collected"]} reviews · {r["negative_pct"]:.1f}% rated 1–2★</div>' for r in summary)}</div></header>
<section><h2>What customers are telling us</h2><div class="callout">Across the sampled low-rated reviews, the recurring friction points are order reliability, item accuracy and quality, payment or refund handling, and getting a useful support response. Positive reviews most often reward speed and convenience. Each app has a different mix; the charts below use ratings and simple keyword tags, so they are descriptive signals rather than a model of every customer's experience.</div>
<table><thead><tr><th>App</th><th>Most-mentioned issues in 1–2★ reviews</th><th>Common praise in 4–5★ reviews</th><th>Sample mean</th></tr></thead><tbody>{''.join(top_lines)}</tbody></table></section>
<section><h2>Sentiment by star rating</h2><div class="chart">{ratings_svg}</div><p class="note">Sentiment is defined from the star score: positive = 4–5, neutral = 3, negative = 1–2. Percentages use the collected review sample for each app.</p></section>
<section><h2>Issue themes in low-rated reviews</h2><div class="chart">{issues_svg}</div><p class="note">One review may mention several themes. Counts are reviews containing at least one keyword for a theme; theme tags are simple English keyword rules and may miss wording in other languages or indirect complaints.</p></section>
<section><h2>Sample coverage</h2><table><thead><tr><th>App</th><th>Reviews collected</th><th>Oldest in sample</th><th>Newest in sample</th><th>1–2★ share</th></tr></thead><tbody>{''.join(sample_table)}</tbody></table>
<p class="note">Fetched {generated} using country=IN, language=en, sort=NEWEST, and a requested limit of {meta["requested_per_app"]} reviews per app. Google Play review availability and ordering can change. This sample is not random or representative of all customers; it is a recent, store-locale-specific sample of public reviews.</p>
<p class="note">Review text was analyzed in memory and is not included in this report or the exported coded rows. The row-level CSV contains ratings, dates, versions, and derived labels only.</p></section>
<section><h2>Practical opportunities</h2><div class="rec-grid">{''.join(f'<div class="rec"><strong>{html.escape(theme)}</strong>{html.escape(text)}</div>' for theme,text in RECOMMENDATIONS.items())}</div></section>
<section><h2>Method and source</h2><p>Reviews were collected from the public Google Play review surface through the open-source <code>google-play-scraper</code> package. The package reads public review data; it is not the authenticated Google Play Developer API. Analysis uses the reviewer star score and transparent keyword matching, not an ML sentiment model.</p>
<ul><li><a href="https://play.google.com/store/apps/details?id=com.grofers.customerapp">Blinkit on Google Play</a> — package <code>com.grofers.customerapp</code></li><li><a href="https://play.google.com/store/apps/details?id=com.zeptoconsumerapp">Zepto on Google Play</a> — package <code>com.zeptoconsumerapp</code></li><li><a href="https://play.google.com/store/apps/details?id=com.bigbasket.mobileapp">BigBasket on Google Play</a> — package <code>com.bigbasket.mobileapp</code></li></ul>
<p class="note">The downloader and analysis are in <code>review_analysis.py</code>. Run instructions and output field definitions are in <code>README.md</code>.</p></section>
</main></body></html>'''
    (output_dir / "report.html").write_text(report, encoding="utf-8")
    (output_dir / "rating_sentiment.svg").write_text(ratings_svg, encoding="utf-8")
    (output_dir / "issue_themes.svg").write_text(issues_svg, encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description="Download and analyze recent Google Play reviews for Blinkit, Zepto, and BigBasket.")
    parser.add_argument("--limit", type=int, default=500, help="Newest reviews requested per app (default: 500).")
    parser.add_argument("--country", default="in", help="Google Play country code (default: in).")
    parser.add_argument("--language", default="en", help="Review language / translation language (default: en).")
    parser.add_argument("--output-dir", default=".", help="Directory for analysis outputs (default: current directory).")
    args = parser.parse_args()
    if args.limit < 1:
        parser.error("--limit must be at least 1")
    try:
        from google_play_scraper import Sort, reviews
    except ImportError:
        print("Missing dependency. Install it with: python -m pip install -r requirements.txt", file=sys.stderr)
        return 2

    output_dir = Path(args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    collected_at = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    metadata = {
        "collected_at_utc": collected_at,
        "source": "Public Google Play reviews via google-play-scraper",
        "country": args.country.lower(),
        "language": args.language.lower(),
        "sort": "NEWEST",
        "requested_per_app": args.limit,
        "apps": [],
        "limitations": [
            "Recent, country- and language-filtered sample; not a random sample of all reviews.",
            "Review text is processed in memory and omitted from exported files.",
            "Keyword tags are transparent heuristics and may miss non-English phrasing or context.",
        ],
    }
    coded_rows: list[dict] = []
    summary_rows: list[dict] = []
    issue_rows: list[dict] = []
    positive_rows: list[dict] = []
    rating_rows: list[dict] = []
    for app in APPS:
        print(f'Fetching up to {args.limit} newest reviews for {app["name"]}...', flush=True)
        review_list, _ = reviews(
            app["package"],
            lang=args.language.lower(),
            country=args.country.lower(),
            sort=Sort.NEWEST,
            count=args.limit,
        )
        # De-duplicate in memory using reviewId, then discard the source text after tagging.
        unique: dict[str, dict] = {}
        for item in review_list:
            key = str(item.get("reviewId") or f'{item.get("at")}:{item.get("score")}:{item.get("content")}')
            unique.setdefault(key, item)
        records = list(unique.values())
        scores = [int(x.get("score") or 0) for x in records if 1 <= int(x.get("score") or 0) <= 5]
        sentiment_counts = Counter(rating_sentiment(score) for score in scores)
        dates = [x.get("at").date().isoformat() for x in records if x.get("at")]
        row = {
            "app_name": app["name"],
            "package_name": app["package"],
            "reviews_collected": len(records),
            "average_rating": round(statistics.mean(scores), 2) if scores else 0.0,
            "positive_count": sentiment_counts["Positive"],
            "neutral_count": sentiment_counts["Neutral"],
            "negative_count": sentiment_counts["Negative"],
            "positive_pct": round(pct(sentiment_counts["Positive"], len(scores)), 1),
            "neutral_pct": round(pct(sentiment_counts["Neutral"], len(scores)), 1),
            "negative_pct": round(pct(sentiment_counts["Negative"], len(scores)), 1),
            "date_from": min(dates) if dates else "",
            "date_to": max(dates) if dates else "",
        }
        summary_rows.append(row)
        for score in range(1, 6):
            rating_rows.append({"app_name": app["name"], "rating": score, "reviews": sum(1 for x in records if int(x.get("score") or 0) == score)})

        issues_by_theme = Counter()
        praises_by_theme = Counter()
        issue_all = Counter()
        for item in records:
            score = int(item.get("score") or 0)
            body = str(item.get("content") or "")
            text = norm_text(body)
            issue_tags = [theme for theme, phrases in ISSUE_THEMES.items() if matches(text, phrases)]
            praise_tags = [theme for theme, phrases in POSITIVE_THEMES.items() if matches(text, phrases)]
            if score <= 2:
                issues_by_theme.update(issue_tags)
            issue_all.update(issue_tags)
            if score >= 4:
                praises_by_theme.update(praise_tags)
            dt = item.get("at")
            coded_rows.append({
                "app_name": app["name"],
                "package_name": app["package"],
                "review_date": dt.date().isoformat() if dt else "",
                "rating": score,
                "sentiment_from_rating": rating_sentiment(score) if 1 <= score <= 5 else "Unknown",
                "helpful_votes": int(item.get("thumbsUpCount") or 0),
                "app_version": str(item.get("reviewCreatedVersion") or ""),
                "issue_themes": "; ".join(issue_tags if score <= 2 else []),
                "positive_themes": "; ".join(praise_tags if score >= 4 else []),
                "text_word_count": len(re.findall(r"\b\w+\b", body)),
            })
        for theme in ISSUE_THEMES:
            issue_rows.append({
                "app_name": app["name"],
                "theme": theme,
                "negative_reviews": issues_by_theme[theme],
                "all_reviews_with_theme": issue_all[theme],
                "negative_share_pct": round(pct(issues_by_theme[theme], sentiment_counts["Negative"]), 1),
            })
        for theme in POSITIVE_THEMES:
            positive_rows.append({
                "app_name": app["name"],
                "theme": theme,
                "positive_reviews": praises_by_theme[theme],
                "positive_share_pct": round(pct(praises_by_theme[theme], sentiment_counts["Positive"]), 1),
            })
        metadata["apps"].append({
            "name": app["name"],
            "package_name": app["package"],
            "requested": args.limit,
            "collected": len(records),
            "oldest_review_date": min(dates) if dates else None,
            "newest_review_date": max(dates) if dates else None,
        })
        print(f'  collected {len(records)}; mean rating {row["average_rating"]:.2f}; 1-2 star share {row["negative_pct"]:.1f}%', flush=True)

    write_csv(output_dir / "coded_reviews.csv", [
        "app_name", "package_name", "review_date", "rating", "sentiment_from_rating",
        "helpful_votes", "app_version", "issue_themes", "positive_themes", "text_word_count",
    ], coded_rows)
    write_csv(output_dir / "app_summary.csv", [
        "app_name", "package_name", "reviews_collected", "average_rating", "positive_count",
        "neutral_count", "negative_count", "positive_pct", "neutral_pct", "negative_pct", "date_from", "date_to",
    ], summary_rows)
    write_csv(output_dir / "rating_distribution.csv", ["app_name", "rating", "reviews"], rating_rows)
    write_csv(output_dir / "issue_theme_counts.csv", ["app_name", "theme", "negative_reviews", "all_reviews_with_theme", "negative_share_pct"], issue_rows)
    write_csv(output_dir / "positive_theme_counts.csv", ["app_name", "theme", "positive_reviews", "positive_share_pct"], positive_rows)
    (output_dir / "collection_metadata.json").write_text(json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8")
    build_report(output_dir, summary_rows, issue_rows, positive_rows, metadata)
    print(f"Analysis written to {output_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
